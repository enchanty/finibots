const Discord = require('discord.js')
const ayarlar = require('../ayarlar.json');
exports.run = async(client, message, args) => {

let fini = ""

/*

.addField('» -Çal- Müzik Dinlersiniz', prefix + 'çal ')
.addField('» -Ses- Müziğin Sesin Ayarlarsınız', prefix + 'ses 1/100')
.addField('» -Geç- Şarkıyı Geçersiniz', prefix + 'geç')
.addField('» -Çalan- Çalan Şarkı Hakkında Bilgi Verir', prefix + 'çalan')
.addField('» -Duraklat- Şarkıyı Durdurursunuz', prefix + 'duraklat')
.addField('» -Devam- Şarkıyı Devam Ettirirsiniz', prefix + 'devam')
.addField('» -Sıra- Kuyruğu Görürsünüz', prefix + 'sıra')

*/
const embed = new Discord.RichEmbed()
.setAuthor("Fimi Bot Yardım Paneli", client.user.avatarURL)
.setDescription('`.çal [Şarkı Adı Veya Link]` \nİstediğiniz şarkıyı dinlemenizi sağlar.\n\n `.ses [1/100]` \nDinlediğiniz şarkının sesini açmanızı sağlar.\n\n `.geç [Ek bir giriş bulunamadı.]` \nSıradaki şarkıya geçmenizi sağlar.\n\n  `.çalan [Ek bir giriş bulunamadı.]` \nÇalan şarkı hakkında bilgi verir.\n\n `.duraklat [Ek bir giriş bulunamadı.]` \nÇalan şarkıyı durdurur.\n\n `.devam [Ek bir giriş bulunamadı.]` \nDurdurulmuş şarkıyı devam ettirir.\n\n `.sıra [Ek bir giriş bulunamadı.]` \nSıraya eklenmiş şarkıları görürsünüz.\n\n ') //\n[Davet Et](https://discord.com) | [Destek Sunucusu](https://discord.com) | [Web Sitesi](https://discord.com)
.setThumbnail(client.user.avatarURL)
.setColor("BLUE")
.setFooter('Bu komutu kullanan kullanıcı ' + message.author.tag, message.author.avatarURL)
message.channel.send(embed)
} 


exports.conf = {
    aliases: []
}
exports.help = {
    name: "yardım"
}